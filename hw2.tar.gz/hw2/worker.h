#ifndef WORKER_H
#define WORKER_H

double compute(int x, int n);

#endif
